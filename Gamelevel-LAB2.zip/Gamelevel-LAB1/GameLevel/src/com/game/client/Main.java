package com.game.client;

import com.game.allenemies.EasyEnemy;
import com.game.allenemies.HardEnemy;
import com.game.enemy.Enemy;
import com.game.gamemanager.GameManager;
import com.game.itemfactory.ItemFactory;
import com.game.items.EasyItemFactory;
import com.game.items.HardItemFactory;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GameManager gameManager = GameManager.getInstance();

        // Start level 1
        int level = gameManager.getCurrentLevel();
        System.out.println("Current Level: " + level);

        // Create enemies and items based on level difficulty
        ItemFactory itemFactory;
        if (level == 1) {
            itemFactory = new EasyItemFactory();
        } else {
            itemFactory = new HardItemFactory();
        }

        Enemy enemy1 = new EasyEnemy();
        Enemy enemy2 = new HardEnemy();

        //Weapon weapon = itemFactory.createWeapon();
        //PowerUp powerUp = itemFactory.createPowerUp();
        itemFactory.createWeapon();
        itemFactory.createPowerUp();

        // Game logic and interactions
        // ...

        // Increase score and check if level is complete
        gameManager.increaseScore(100);
        if (enemy1.isDefeated() && enemy2.isDefeated()) {
            gameManager.startNextLevel();
        }

        // Get current score and level
        int score = gameManager.getScore();
        level = gameManager.getCurrentLevel();
        System.out.println("Score: " + score);
        System.out.println("Current Level: " + level);
	}

}
