package com.game.powerup;

public abstract class PowerUp {
	 public abstract void activate();
	 public abstract void deactivate();
}
