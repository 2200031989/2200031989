package com.game.gamemanager;

public class GameManager {
	private static GameManager instance;

    private int currentLevel;
    private int score;

    private GameManager() {
        currentLevel = 1;
        score = 0;
    }

    public static GameManager getInstance() {
        if (instance == null) {
            instance = new GameManager();
        }
        return instance;
    }

    public void increaseScore(int points) {
        score += points;
    }

    public int getScore() {
        return score;
    }

    public int getCurrentLevel() {
        return currentLevel;
    }

    public void startNextLevel() {
        currentLevel++;
        score = 0;
        // Logic for starting the next level
        // ...
    }
}
