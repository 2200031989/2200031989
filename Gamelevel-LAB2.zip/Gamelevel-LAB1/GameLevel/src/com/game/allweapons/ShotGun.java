package com.game.allweapons;

import com.game.weapon.Weapon;

public class ShotGun extends Weapon{

	public ShotGun() {
        damage = 50;
    }
	@Override
	public void fire() {
		// TODO Auto-generated method stub
		
	}

}
