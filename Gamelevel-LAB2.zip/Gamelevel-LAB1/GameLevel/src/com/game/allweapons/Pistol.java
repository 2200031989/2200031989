package com.game.allweapons;

import com.game.weapon.Weapon;

public class Pistol extends Weapon {

	@Override
	public void fire() {
		// TODO Auto-generated method stub
		
	}

}
