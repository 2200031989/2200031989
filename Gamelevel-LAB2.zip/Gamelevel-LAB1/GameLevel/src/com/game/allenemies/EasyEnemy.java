package com.game.allenemies;

import com.game.enemy.Enemy;

public class EasyEnemy extends Enemy{
	public EasyEnemy() {
        health = 50;
        damage = 10;
    }
	@Override
	public void attack() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void takeDamage(int damage) {
		// TODO Auto-generated method stub
		health -= damage;
	}

}
