package com.game.allenemies;

import com.game.enemy.Enemy;

public class HardEnemy extends Enemy {
	public HardEnemy() {
        health = 100;
        damage = 20;
    }
	@Override
	public void attack() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void takeDamage(int damage) {
		// TODO Auto-generated method stub
		health -= damage;
	}

}
