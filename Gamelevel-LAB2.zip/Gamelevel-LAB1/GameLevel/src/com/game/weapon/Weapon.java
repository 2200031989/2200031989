package com.game.weapon;

public abstract class Weapon {
	
	protected int damage;
    public abstract void fire();
    public int getDamage() {
        return damage;
    }
}
