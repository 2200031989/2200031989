package com.game.items;

import com.game.allpowerups.HealthPowerUp;
import com.game.allweapons.Pistol;
import com.game.itemfactory.ItemFactory;
import com.game.powerup.PowerUp;
import com.game.weapon.Weapon;

public class EasyItemFactory extends ItemFactory{

	@Override
	public Weapon createWeapon() {
		// TODO Auto-generated method stub
		return new Pistol();
	}

	@Override
	public PowerUp createPowerUp() {
		// TODO Auto-generated method stub
		return new HealthPowerUp();
	}

}
