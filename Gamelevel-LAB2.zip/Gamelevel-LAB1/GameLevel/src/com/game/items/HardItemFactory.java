package com.game.items;

import com.game.allpowerups.ShieldPowerUp;
import com.game.allweapons.ShotGun;
import com.game.itemfactory.ItemFactory;
import com.game.powerup.PowerUp;
import com.game.weapon.Weapon;

public class HardItemFactory extends ItemFactory {

	@Override
	public Weapon createWeapon() {
		// TODO Auto-generated method stub
		return new ShotGun();
	}

	@Override
	public PowerUp createPowerUp() {
		// TODO Auto-generated method stub
		return new ShieldPowerUp();
	}

}
