package com.game.allpowerups;

import com.game.powerup.PowerUp;

public class ShieldPowerUp extends PowerUp{

	@Override
	public void activate() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deactivate() {
		// TODO Auto-generated method stub
		
	}

}
