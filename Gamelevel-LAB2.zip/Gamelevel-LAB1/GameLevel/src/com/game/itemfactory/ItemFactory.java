package com.game.itemfactory;

import com.game.powerup.PowerUp;
import com.game.weapon.Weapon;

public abstract class ItemFactory {
	
	public abstract Weapon createWeapon();

    public abstract PowerUp createPowerUp();
}
