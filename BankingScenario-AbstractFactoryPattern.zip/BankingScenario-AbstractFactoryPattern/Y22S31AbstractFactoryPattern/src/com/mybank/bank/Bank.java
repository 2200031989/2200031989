package com.mybank.bank;

public interface Bank {
	public String getBankName();
}
