package com.mybank.abstractfactory;

import com.mybank.bank.Bank;
import com.mybank.loanclass.Loan;

public abstract class AbstractFactory {
	public abstract Bank getBankFactory(String bank);
	public abstract Loan getLoanFactory(String loan);
}
