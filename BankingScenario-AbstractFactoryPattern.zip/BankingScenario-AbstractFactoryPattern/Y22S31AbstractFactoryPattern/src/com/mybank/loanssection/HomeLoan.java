package com.mybank.loanssection;

import com.mybank.loanclass.Loan;

public class HomeLoan extends Loan{

	@Override
	public void getInterestRate(double rate) {
		this.rate = rate;
		
	}

}
