package com.mybank.loanssection;

import com.mybank.loanclass.Loan;

public class CarLoan extends Loan{

	@Override
	public void getInterestRate(double rate) {
		this.rate = rate;
		
	}

}
