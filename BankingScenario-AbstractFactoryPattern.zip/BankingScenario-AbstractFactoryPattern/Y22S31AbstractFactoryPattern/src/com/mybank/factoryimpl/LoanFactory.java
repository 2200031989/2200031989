package com.mybank.factoryimpl;

import com.mybank.abstractfactory.AbstractFactory;
import com.mybank.bank.Bank;
import com.mybank.loanclass.Loan;
import com.mybank.loanssection.CarLoan;
import com.mybank.loanssection.HomeLoan;

public class LoanFactory extends AbstractFactory{

	@Override
	public Bank getBankFactory(String bank) {
		return null;
		
	}

	@Override
	public Loan getLoanFactory(String loan) {
		if(loan.equalsIgnoreCase("Homeloan")) {
			return new HomeLoan();
		}else if(loan.equalsIgnoreCase("Carloan")) {
			return new CarLoan();
		}return null;
		
	}

}
