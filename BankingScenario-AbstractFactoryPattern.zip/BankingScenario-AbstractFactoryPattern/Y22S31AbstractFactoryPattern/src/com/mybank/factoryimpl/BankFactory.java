package com.mybank.factoryimpl;

import com.mybank.abstractfactory.AbstractFactory;
import com.mybank.bank.Bank;
import com.mybank.bankimpl.AXIS;
import com.mybank.bankimpl.HDFC;
import com.mybank.loanclass.Loan;

public class BankFactory extends  AbstractFactory{

	@Override
	public Bank getBankFactory(String bank) {
		if(bank.equalsIgnoreCase("HDFC")) {
			return new HDFC();
		}else if(bank.equalsIgnoreCase("AXIS")) {
			return new AXIS();
		}return null;
		
	}

	@Override
	public Loan getLoanFactory(String loan) {
		return null;
		
	}

}
