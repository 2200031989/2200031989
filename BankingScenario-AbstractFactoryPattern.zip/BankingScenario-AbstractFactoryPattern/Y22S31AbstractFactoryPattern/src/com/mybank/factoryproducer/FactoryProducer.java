package com.mybank.factoryproducer;

import com.mybank.abstractfactory.AbstractFactory;
import com.mybank.factoryimpl.BankFactory;
import com.mybank.factoryimpl.LoanFactory;

public class FactoryProducer {
	public static AbstractFactory getFactory(String type) {
		if(type.equalsIgnoreCase("Bank")) {
			return new BankFactory();
		}else if(type.equalsIgnoreCase("Loan")) {
			return new LoanFactory();
		}return null;
	}
}
