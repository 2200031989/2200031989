package com.mybank.client;

import java.util.Scanner;

import com.mybank.abstractfactory.AbstractFactory;
import com.mybank.bank.Bank;
import com.mybank.factoryproducer.FactoryProducer;
import com.mybank.loanclass.Loan;

public class Client {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the bank name :");
		String bankName = scanner.nextLine();
		
		AbstractFactory newFactory = FactoryProducer.getFactory("Bank");
		Bank bankimpl = newFactory.getBankFactory(bankName);
		
		System.out.println("enter loan type :");
		String loanName = scanner.nextLine();
		
		System.out.println("Enter rate of interest in :"+bankimpl.getBankName());
		double rate = Double.parseDouble(scanner.nextLine());
		
		System.out.println("Enter loanamount : ");
		double loanamount = Double.parseDouble(scanner.nextLine());
		
		System.out.println("Enter time in years : ");
		int year = Integer.parseInt(scanner.nextLine());
		
		AbstractFactory lf = FactoryProducer.getFactory("Loan");
		Loan loanimpl = lf.getLoanFactory(loanName);
		
		loanimpl.getInterestRate(rate);
		loanimpl.calculatePayment(loanamount, year);
		

	}

}
