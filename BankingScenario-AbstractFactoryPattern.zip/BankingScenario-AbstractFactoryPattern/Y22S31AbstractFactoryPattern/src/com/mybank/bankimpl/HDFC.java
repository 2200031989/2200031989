package com.mybank.bankimpl;

import com.mybank.bank.Bank;

public class HDFC implements Bank {
	
	protected final String BNAME;
	
	public HDFC() {
		BNAME = "HDFC BANK";
	}
	@Override
	public String getBankName() {
		return BNAME;
		
	}
	
}
