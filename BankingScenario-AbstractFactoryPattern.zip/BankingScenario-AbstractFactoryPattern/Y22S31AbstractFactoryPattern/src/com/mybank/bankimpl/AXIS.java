package com.mybank.bankimpl;

import com.mybank.bank.Bank;

public class AXIS implements Bank{
	protected final String BNAME;
	
	public AXIS() {
		BNAME = "AXIS BANK";
	}
	@Override
	public String getBankName() {
		return BNAME;
		
	}
}
