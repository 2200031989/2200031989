package com.aoop.logger;
class Logger {
    // Private static variable to hold the single instance of the Logger class
    private static Logger instance;

    // Private constructor to prevent instantiation from outside the class
    private Logger() {
        // Initialization code, if any
    }

    // Public static method to get the single instance of the Logger class
    public static Logger getInstance() {
        if (instance == null) {
            synchronized (Logger.class) {
                if (instance == null) {
                    instance = new Logger();
                }
            }
        }
        return instance;
    }

    // Public method to log a message
    public void log(String message) {
        // Logging implementation here
        System.out.println("Logging message: " + message);
    }
}

public class MyApp {
    public static void main(String[] args) {
        Logger logger = Logger.getInstance();
        logger.log("Application started.");
        
        logger.log("Some event occurred.");
      
        logger.log("Application ended.");
    }
}

